
class CitaPrevia {
    constructor (fechaHora,paciente,medico){
        this.fechaHora=fechaHora;
        this.paciente=paciente;
        this.medico=medico;
    
    };


}